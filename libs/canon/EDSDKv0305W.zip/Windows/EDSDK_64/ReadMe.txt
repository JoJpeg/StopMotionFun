-----------------------------------------------------------------------------------
                             EDSDK 64-bit Library
                                 README File
                           Copyright CANON INC. 2016
-----------------------------------------------------------------------------------
This Readme file contains the latest information about the EDSDK 64-bit Library.
Please read this file before using the EDSDK 64-bit Library.
-----------------------------------------------------------------------------------

About EDSDK 64-bit library
------------------
EDSDK is not 64-Bit compatible. You cannot call the EDSDK library from an application of 64bit.
For the camera connect functions and limited supported cameras for the image handling functions, we released a 64-bit
library as a beta version on a trial basis.

Please note:Supported cameras are limited for the image hadling functions in 64-Bit module. 
Please refer to the EDSDK document for the limited supported camera list(1.2.1 Target Enviroment).
